/*
  # Add email field to profiles table

  1. Changes
    - Add email column to profiles table
    - Add index for email lookups
    - Update existing profiles with email from auth.users
*/

-- Add email column to profiles table if it doesn't exist
BEGIN;

-- Add email column to profiles table if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_attribute 
    WHERE attrelid = 'profiles'::regclass 
      AND attname = 'email' 
      AND NOT attisdropped
  ) THEN
    ALTER TABLE profiles ADD COLUMN email TEXT;
  END IF;
EXCEPTION WHEN OTHERS THEN
  RAISE NOTICE 'Error adding email column: %', SQLERRM;
  ROLLBACK;  -- Ensure partial updates don't get committed
END $$;

-- Create index for email lookups
CREATE INDEX IF NOT EXISTS idx_profiles_email ON profiles(email);

-- Update existing profiles with email from auth.users
UPDATE profiles p
SET email = u.email
FROM auth.users u
WHERE p.id = u.id
  AND p.email IS NULL;

-- Drop existing trigger (if needed) to avoid conflicts
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM pg_trigger 
    WHERE tgname = 'trigger_update_email'
  ) THEN
    DROP TRIGGER trigger_update_email ON profiles;
  END IF;
END $$;

-- Create function to auto-insert email for new profiles
CREATE OR REPLACE FUNCTION update_profiles_email()
RETURNS TRIGGER AS $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM auth.users WHERE id = NEW.id
  ) THEN
    NEW.email := (SELECT email FROM auth.users WHERE id = NEW.id);
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for new profile entries
CREATE TRIGGER trigger_update_email
BEFORE INSERT ON profiles
FOR EACH ROW
EXECUTE FUNCTION update_profiles_email();

COMMIT;
