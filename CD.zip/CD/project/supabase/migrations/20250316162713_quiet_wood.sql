/*
  # User Management Views and Functions

  1. New Views
    - `user_role_counts` - Aggregates user counts by role
    - `user_activity_summary` - Tracks user activity and last login
    - `user_department_stats` - Statistics by department
  
  2. Functions
    - Functions to manage user roles and permissions
    - Functions to track user activity
  
  3. Triggers
    - Automatic activity logging
    - Role change tracking
*/

-- Add the 'last_login' column to the profiles table
ALTER TABLE profiles 
ADD COLUMN last_login TIMESTAMP DEFAULT NULL;

-- Create view for user role counts
CREATE OR REPLACE VIEW user_role_counts AS
SELECT 
  role,
  COUNT(*) as total_users,
  COUNT(*) FILTER (WHERE created_at >= NOW() - INTERVAL '30 days') as new_users,
  COUNT(*) FILTER (WHERE last_login >= NOW() - INTERVAL '7 days') as active_users
FROM profiles
GROUP BY role;

-- Create view for user activity summary
CREATE OR REPLACE VIEW user_activity_summary AS
SELECT 
  p.id,
  p.email,
  p.first_name,
  p.last_name,
  p.role,
  p.department,
  p.last_login,
  p.created_at,
  COUNT(al.id) as total_actions,
  MAX(al.created_at) as last_action
FROM profiles p
LEFT JOIN action_logs al ON p.id = al.user_id
GROUP BY p.id, p.email, p.first_name, p.last_name, p.role, p.department, p.last_login, p.created_at;

-- Create view for department statistics
CREATE OR REPLACE VIEW user_department_stats AS
SELECT 
  department,
  COUNT(*) as total_users,
  COUNT(DISTINCT role) as unique_roles,
  MAX(created_at) as latest_user_added,
  COUNT(*) FILTER (WHERE role = 'procurement_officer') as procurement_officers,
  COUNT(*) FILTER (WHERE role = 'vendor') as vendors
FROM profiles
WHERE department IS NOT NULL
GROUP BY department;

-- Function to log user role changes
CREATE OR REPLACE FUNCTION log_user_role_change()
RETURNS TRIGGER AS $$
BEGIN
  IF OLD.role IS DISTINCT FROM NEW.role THEN
    INSERT INTO action_logs (
      user_id,
      action_type,
      entity_type,
      entity_id,
      details
    ) VALUES (
      auth.uid(),
      'role_change',
      'user',
      NEW.id,
      jsonb_build_object(
        'previous_role', OLD.role,
        'new_role', NEW.role,
        'changed_by', auth.uid()
      )
    );
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for role changes
DROP TRIGGER IF EXISTS on_user_role_change ON profiles;
CREATE TRIGGER on_user_role_change
  AFTER UPDATE OF role ON profiles
  FOR EACH ROW EXECUTE FUNCTION log_user_role_change();

-- Function to get user activity details
CREATE OR REPLACE FUNCTION get_user_activity(user_id UUID)
RETURNS TABLE (
  action_type TEXT,
  entity_type TEXT,
  details JSONB,
  created_at TIMESTAMPTZ
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    al.action_type,
    al.entity_type,
    al.details,
    al.created_at
  FROM action_logs al
  WHERE al.user_id = user_id
  ORDER BY al.created_at DESC
  LIMIT 50;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to get department summary
CREATE OR REPLACE FUNCTION get_department_summary(dept TEXT)
RETURNS TABLE (
  role TEXT,
  user_count INTEGER,
  active_users INTEGER,
  last_active TIMESTAMPTZ
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    p.role,
    COUNT(*) as user_count,
    COUNT(*) FILTER (WHERE p.last_login >= NOW() - INTERVAL '7 days') as active_users,
    MAX(p.last_login) as last_active
  FROM profiles p
  WHERE p.department = dept
  GROUP BY p.role;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_profiles_department_role 
  ON profiles(department, role);

CREATE INDEX IF NOT EXISTS idx_profiles_last_login 
  ON profiles(last_login);

-- Grant necessary permissions
GRANT SELECT ON user_role_counts TO authenticated;
GRANT SELECT ON user_activity_summary TO authenticated;
GRANT SELECT ON user_department_stats TO authenticated;
