import { Outlet, Link, useLocation, useNavigate } from 'react-router-dom';
import {
  HomeIcon,
  UserGroupIcon,
  DocumentTextIcon,
  CreditCardIcon,
  ChartBarIcon,
  ShieldCheckIcon,
  Cog6ToothIcon,
  UserIcon,
} from '@heroicons/react/24/outline';
import { useAuth } from '../../hooks/useAuth';

export default function AdminDashboardLayout() {
  const location = useLocation();
  const navigate = useNavigate();
  const { user, signOut } = useAuth();

  const navigationItems = [
    { name: 'AdminDashboard', path: '/admin', icon: HomeIcon },
    { name: 'UserManagement', path: '/admin/users', icon: UserGroupIcon },
   /* 
    { name: 'TenderManagement', path: '/admin/tender-management', icon: DocumentTextIcon },
    { name: 'Vendors', path: '/admin/vendors', icon: UserGroupIcon },
    { name: 'Payments', path: '/admin/payments', icon: CreditCardIcon },
    { name: 'Reports', path: '/admin/reports', icon: ChartBarIcon },
    { name: 'Compliance', path: '/admin/compliance', icon: ShieldCheckIcon },
    { name: 'Settings', path: '/admin/settings', icon: Cog6ToothIcon },
     */
    
    { name: 'Profile', path: '/admin/profile', icon: UserIcon },
  ];

  const handleSignOut = async () => {
    try {
      await signOut();
      navigate('/login');
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-primary-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <Link to="/admin" className="text-xl font-bold">
                NEEPCO Admin
              </Link>
            </div>
            <nav className="hidden md:flex items-center space-x-4">
              {navigationItems.map((item) => {
                const isActive = location.pathname === item.path;
                return (
                  <Link
                    key={item.name}
                    to={item.path}
                    className={`flex items-center px-3 py-2 rounded-md text-sm font-medium ${
                      isActive
                        ? 'bg-primary-800 text-white'
                        : 'text-primary-100 hover:bg-primary-600'
                    }`}
                  >
                    <item.icon className="h-5 w-5 mr-2" />
                    {item.name}
                  </Link>
                );
              })}
              {user && (
                <div className="flex items-center space-x-4">
                  <span className="text-sm text-primary-100">
                    Admin
                  </span>
                  
                  <button
                    onClick={() => {
                      handleSignOut();
                      navigate('/signout');
                    }}
                    className="flex items-center px-3 py-2 rounded-md text-sm font-medium text-primary-100 hover:bg-primary-600"
                  >
                    Sign Out
                  </button>
                </div>
              )}
            </nav>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Outlet />
      </main>

      <footer className="bg-gray-800 text-white mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <p className="text-center text-sm">
            © 2024 NEEPCO Admin Portal |{' '}
            <Link to="/terms" className="hover:text-primary-300">
              Terms & Conditions
            </Link>{' '}
            |{' '}
            <Link to="/privacy" className="hover:text-primary-300">
              Privacy Policy
            </Link>
          </p>
        </div>
      </footer>
    </div>
  );
}