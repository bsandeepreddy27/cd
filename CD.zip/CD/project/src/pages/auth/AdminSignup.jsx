import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Formik, Form, Field } from 'formik';
import * as Yup from 'yup';
import { useAuth } from '../../hooks/useAuth';
import { toast } from 'react-hot-toast';
import { supabase } from '../../lib/supabase';

const adminSignupSchema = Yup.object().shape({
  email: Yup.string().email('Invalid email').required('Email is required'),
  password: Yup.string()
    .min(8, 'Password must be at least 8 characters')
    .required('Password is required'),
  confirmPassword: Yup.string()
    .oneOf([Yup.ref('password'), null], 'Passwords must match')
    .required('Confirm password is required'),
  firstName: Yup.string().required('First name is required'),
  lastName: Yup.string().required('Last name is required'),
  department: Yup.string().required('Department is required'),
  employeeId: Yup.string().required('Employee ID is required'),
  adminCode: Yup.string().required('Admin registration code is required'),
});

export default function AdminSignup() {
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState(null);
  const navigate = useNavigate();
  const { signUp } = useAuth();

  const handleSubmit = async (values, { setSubmitting }) => {
    try {
      setError(null);

      // First validate the admin registration code
      const { data: isValid, error: validationError } = await supabase
        .rpc('validate_admin_registration_code', {
          registration_code: values.adminCode
        });

      if (validationError) throw validationError;
      if (!isValid) {
        throw new Error('Invalid or expired admin registration code');
      }
      
      // Prepare user metadata
      const userMetadata = {
        role: 'admin',
        firstName: values.firstName,
        lastName: values.lastName,
        department: values.department,
        employeeId: values.employeeId,
      };
      
      // Create the admin account
      const { data, error: signUpError } = await signUp({
        email: values.email,
        password: values.password,
        options: {
          data: userMetadata
        }
      });
      
      if (signUpError) {
        if (signUpError.code === 'user_already_exists') {
          throw new Error('An account with this email already exists. Please use a different email or try logging in.');
        }
        throw signUpError;
      }

      // Mark the registration code as used
      const { error: useCodeError } = await supabase
        .rpc('use_admin_registration_code', {
          registration_code: values.adminCode,
          user_id: data.user.id
        });

      if (useCodeError) throw useCodeError;
      
      toast.success('Admin account created successfully! Please check your email for confirmation.');
      navigate('/login');
    } catch (error) {
      console.error('Signup error:', error);
      let errorMessage = 'An error occurred during signup. Please try again.';
      
      if (error.status === 503) {
        errorMessage = 'Connection to authentication service failed. Please try again later.';
      } else if (error.status === 500) {
        errorMessage = 'Server error. This could be due to a temporary service issue.';
      } else if (error.message) {
        errorMessage = error.message;
      }
      
      setError(errorMessage);
      toast.error(errorMessage);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">
          Create Admin Account
        </h2>
        <p className="mt-2 text-center text-sm text-gray-600">
          Register as a system administrator
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-4 shadow sm:rounded-lg sm:px-10">
          {error && (
            <div className="mb-4 bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded">
              {error}
            </div>
          )}

          <Formik
            initialValues={{
              email: '',
              password: '',
              confirmPassword: '',
              firstName: '',
              lastName: '',
              department: '',
              employeeId: '',
              adminCode: '',
            }}
            validationSchema={adminSignupSchema}
            onSubmit={handleSubmit}
          >
            {({ errors, touched, isSubmitting }) => (
              <Form className="space-y-6">
                <div className="grid grid-cols-1 gap-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="firstName" className="block text-sm font-medium text-gray-700">
                        First Name
                      </label>
                      <Field
                        name="firstName"
                        type="text"
                        className="input mt-1"
                        placeholder="Enter your first name"
                      />
                      {errors.firstName && touched.firstName && (
                        <div className="mt-1 text-sm text-red-600">{errors.firstName}</div>
                      )}
                    </div>

                    <div>
                      <label htmlFor="lastName" className="block text-sm font-medium text-gray-700">
                        Last Name
                      </label>
                      <Field
                        name="lastName"
                        type="text"
                        className="input mt-1"
                        placeholder="Enter your last name"
                      />
                      {errors.lastName && touched.lastName && (
                        <div className="mt-1 text-sm text-red-600">{errors.lastName}</div>
                      )}
                    </div>
                  </div>

                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                      Email
                    </label>
                    <Field
                      name="email"
                      type="email"
                      className="input mt-1"
                      placeholder="Enter your email"
                    />
                    {errors.email && touched.email && (
                      <div className="mt-1 text-sm text-red-600">{errors.email}</div>
                    )}
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label htmlFor="password" className="block text-sm font-medium text-gray-700">
                        Password
                      </label>
                      <div className="mt-1 relative">
                        <Field
                          name="password"
                          type={showPassword ? 'text' : 'password'}
                          className="input pr-10"
                          placeholder="Enter password"
                        />
                        <button
                          type="button"
                          className="absolute inset-y-0 right-0 pr-3 flex items-center"
                          onClick={() => setShowPassword(!showPassword)}
                        >
                          {showPassword ? '👁️' : '👁️‍🗨️'}
                        </button>
                      </div>
                      {errors.password && touched.password && (
                        <div className="mt-1 text-sm text-red-600">{errors.password}</div>
                      )}
                    </div>

                    <div>
                      <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700">
                        Confirm Password
                      </label>
                      <Field
                        name="confirmPassword"
                        type={showPassword ? 'text' : 'password'}
                        className="input mt-1"
                        placeholder="Confirm password"
                      />
                      {errors.confirmPassword && touched.confirmPassword && (
                        <div className="mt-1 text-sm text-red-600">{errors.confirmPassword}</div>
                      )}
                    </div>
                  </div>

                  <div>
                    <label htmlFor="department" className="block text-sm font-medium text-gray-700">
                      Department
                    </label>
                    <Field
                      name="department"
                      type="text"
                      className="input mt-1"
                      placeholder="Enter your department"
                    />
                    {errors.department && touched.department && (
                      <div className="mt-1 text-sm text-red-600">{errors.department}</div>
                    )}
                  </div>

                  <div>
                    <label htmlFor="employeeId" className="block text-sm font-medium text-gray-700">
                      Employee ID
                    </label>
                    <Field
                      name="employeeId"
                      type="text"
                      className="input mt-1"
                      placeholder="Enter your employee ID"
                    />
                    {errors.employeeId && touched.employeeId && (
                      <div className="mt-1 text-sm text-red-600">{errors.employeeId}</div>
                    )}
                  </div>

                  <div>
                    <label htmlFor="adminCode" className="block text-sm font-medium text-gray-700">
                      Admin Registration Code
                    </label>
                    <Field
                      name="adminCode"
                      type="password"
                      className="input mt-1"
                      placeholder="Enter admin registration code"
                    />
                    {errors.adminCode && touched.adminCode && (
                      <div className="mt-1 text-sm text-red-600">{errors.adminCode}</div>
                    )}
                  </div>
                </div>

                <div>
                  <button
                    type="submit"
                    className="w-full btn btn-primary"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? 'Creating Account...' : 'Create Admin Account'}
                  </button>
                </div>

                <div className="mt-6 text-sm text-center">
                  Already have an account?{' '}
                  <Link to="/login" className="text-primary-600 hover:text-primary-500">
                    Login here
                  </Link>
                </div>
              </Form>
            )}
          </Formik>
        </div>
      </div>
    </div>
  );
}