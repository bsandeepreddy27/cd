import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { format } from 'date-fns';
import { supabase } from '../../lib/supabase';
import { useAuth } from '../../hooks/useAuth';
import LoadingSpinner from '../../components/ui/LoadingSpinner';
import { toast } from 'react-hot-toast';
import { useNavigate } from 'react-router-dom';

export default function AdminProfile() {
  const [isEditing, setIsEditing] = useState(false);
  const [activeTab, setActiveTab] = useState('profile');
  const queryClient = useQueryClient();
  const { user, hasRole } = useAuth();
  const navigate = useNavigate();

  // Only allow admin access
  if (!hasRole('admin')) {
    navigate('/');
    return null;
  }

  const { data: profile, isLoading: isLoadingProfile } = useQuery({
    queryKey: ['admin-profile', user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .single();

      if (error) throw error;
      return data;
    },
    enabled: !!user,
  });

  // Get registration codes
  const { data: registrationCodes, isLoading: isLoadingCodes } = useQuery({
    queryKey: ['admin-registration-codes'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('admin_registration_codes')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data || [];
    },
  });

  // Get action logs
  const { data: actionLogs, isLoading: isLoadingLogs } = useQuery({
    queryKey: ['admin-action-logs'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('action_logs')
        .select(`
          *,
          profiles:user_id (
            first_name,
            last_name,
            email
          )
        `)
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) throw error;
      return data || [];
    },
  });

  const updateProfile = useMutation({
    mutationFn: async (updates) => {
      const { data, error } = await supabase
        .from('profiles')
        .update(updates)
        .eq('id', user.id)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['admin-profile', user?.id]);
      setIsEditing(false);
      toast.success('Profile updated successfully');
    },
    onError: (error) => {
      toast.error(error.message || 'Failed to update profile');
    },
  });

  const createRegistrationCode = useMutation({
    mutationFn: async () => {
      const code = `ADMIN${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
      const { data, error } = await supabase
        .from('admin_registration_codes')
        .insert([{
          code,
          expires_at: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000), // 7 days
          created_by: user.id
        }])
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['admin-registration-codes']);
      toast.success('Registration code created successfully');
    },
    onError: (error) => {
      toast.error(error.message || 'Failed to create registration code');
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);
    
    updateProfile.mutate({
      first_name: formData.get('firstName'),
      last_name: formData.get('lastName'),
      department: formData.get('department'),
    });
  };

  if (isLoadingProfile || isLoadingCodes || isLoadingLogs) {
    return <LoadingSpinner />;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-900">Admin Profile</h1>
        <div className="flex space-x-2">
          {activeTab === 'profile' && (
            <button
              onClick={() => setIsEditing(!isEditing)}
              className="btn btn-primary"
            >
              {isEditing ? 'Cancel' : 'Edit Profile'}
            </button>
          )}
          {activeTab === 'registration' && (
            <button
              onClick={() => createRegistrationCode.mutate()}
              className="btn btn-primary"
              disabled={createRegistrationCode.isLoading}
            >
              {createRegistrationCode.isLoading ? 'Creating...' : 'Generate New Code'}
            </button>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b border-gray-200">
        <nav className="-mb-px flex space-x-8">
          <button
            onClick={() => setActiveTab('profile')}
            className={`${
              activeTab === 'profile'
                ? 'border-primary-500 text-primary-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
          >
            Profile
          </button>
          <button
            onClick={() => setActiveTab('registration')}
            className={`${
              activeTab === 'registration'
                ? 'border-primary-500 text-primary-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
          >
            Registration Codes
          </button>
          <button
            onClick={() => setActiveTab('activity')}
            className={`${
              activeTab === 'activity'
                ? 'border-primary-500 text-primary-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
          >
            Activity Log
          </button>
        </nav>
      </div>

      {/* Profile Tab */}
      {activeTab === 'profile' && (
        <div className="card">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Admin Information</h2>
          {isEditing ? (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700">First Name</label>
                  <input
                    name="firstName"
                    defaultValue={profile.first_name}
                    className="input mt-1"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Last Name</label>
                  <input
                    name="lastName"
                    defaultValue={profile.last_name}
                    className="input mt-1"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Department</label>
                  <input
                    name="department"
                    defaultValue={profile.department}
                    className="input mt-1"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Email</label>
                  <input
                    name="email"
                    defaultValue={user.email}
                    className="input mt-1"
                    disabled
                  />
                  <p className="mt-1 text-sm text-gray-500">Email cannot be changed</p>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Role</label>
                  <input
                    name="role"
                    defaultValue="Administrator"
                    className="input mt-1"
                    disabled
                  />
                  <p className="mt-1 text-sm text-gray-500">Role cannot be changed</p>
                </div>
                {profile.employee_id && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700">Employee ID</label>
                    <input
                      name="employeeId"
                      defaultValue={profile.employee_id}
                      className="input mt-1"
                      disabled
                    />
                    <p className="mt-1 text-sm text-gray-500">Employee ID cannot be changed</p>
                  </div>
                )}
              </div>
              <div className="flex justify-end space-x-2">
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  className="btn btn-secondary"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={updateProfile.isLoading}
                  className="btn btn-primary"
                >
                  {updateProfile.isLoading ? 'Saving...' : 'Save Changes'}
                </button>
              </div>
            </form>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <p className="text-sm font-medium text-gray-500">Name</p>
                <p className="mt-1 text-lg text-gray-900">
                  {profile.first_name} {profile.last_name}
                </p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">Email</p>
                <p className="mt-1 text-lg text-gray-900">{user.email}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">Department</p>
                <p className="mt-1 text-lg text-gray-900">{profile.department || 'Not specified'}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-gray-500">Role</p>
                <p className="mt-1">
                  <span className="px-2 py-1 rounded-full text-sm font-medium bg-red-100 text-red-800">
                    Administrator
                  </span>
                </p>
              </div>
              {profile.employee_id && (
                <div>
                  <p className="text-sm font-medium text-gray-500">Employee ID</p>
                  <p className="mt-1 text-lg text-gray-900">{profile.employee_id}</p>
                </div>
              )}
              <div>
                <p className="text-sm font-medium text-gray-500">Account Created</p>
                <p className="mt-1 text-lg text-gray-900">
                  {profile.created_at ? format(new Date(profile.created_at), 'PPp') : 'Unknown'}
                </p>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Registration Codes Tab */}
      {activeTab === 'registration' && (
        <div className="card">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Admin Registration Codes</h2>
          {registrationCodes && registrationCodes.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Code
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Expires
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Used By
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Created At
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {registrationCodes.map((code) => (
                    <tr key={code.id}>
                      <td className="px-6 py-4 whitespace-nowrap font-mono">
                        {code.code}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          code.is_used
                            ? 'bg-gray-100 text-gray-800'
                            : new Date(code.expires_at) < new Date()
                            ? 'bg-red-100 text-red-800'
                            : 'bg-green-100 text-green-800'
                        }`}>
                          {code.is_used ? 'Used' : new Date(code.expires_at) < new Date() ? 'Expired' : 'Active'}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {format(new Date(code.expires_at), 'PP')}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {code.used_by ? format(new Date(code.used_at), 'PP') : '-'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {format(new Date(code.created_at), 'PP')}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <div className="bg-gray-50 p-6 rounded-lg text-center">
              <p className="text-gray-600">No registration codes found.</p>
            </div>
          )}
        </div>
      )}

      {/* Activity Log Tab */}
      {activeTab === 'activity' && (
        <div className="card">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Activity Log</h2>
          {actionLogs && actionLogs.length > 0 ? (
            <div className="space-y-4">
              {actionLogs.map((log) => (
                <div key={log.id} className="bg-white p-4 rounded-lg shadow-sm border border-gray-200">
                  <div className="flex items-start">
                    <div className="flex-shrink-0">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                        log.action_type === 'status_change' 
                          ? 'bg-blue-100 text-blue-600' 
                          : log.action_type === 'technical_score_update'
                          ? 'bg-yellow-100 text-yellow-600'
                          : 'bg-gray-100 text-gray-600'
                      }`}>
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                      </div>
                    </div>
                    <div className="ml-4">
                      <div className="text-sm font-medium text-gray-900">
                        {log.profiles?.first_name} {log.profiles?.last_name}
                      </div>
                      <div className="text-sm text-gray-500">
                        {log.action_type === 'status_change' && log.entity_type === 'tender' && (
                          <>Tender "{log.details.tender_title}" status changed from {log.details.previous_status.replace('_', ' ')} to {log.details.new_status.replace('_', ' ')}</>
                        )}
                        {log.action_type === 'status_change' && log.entity_type === 'bid' && (
                          <>Bid for "{log.details.tender_title}" status changed from {log.details.previous_status.replace('_', ' ')} to {log.details.new_status.replace('_', ' ')}</>
                        )}
                        {log.action_type === 'technical_score_update' && (
                          <>Technical score for bid on "{log.details.tender_title}" updated to {log.details.new_score}%</>
                        )}
                      </div>
                      <div className="text-xs text-gray-400 mt-1">
                        {format(new Date(log.created_at), 'PPp')}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="bg-gray-50 p-6 rounded-lg text-center">
              <p className="text-gray-600">No activity logs found.</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}