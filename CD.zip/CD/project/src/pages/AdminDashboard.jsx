import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link, useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';
import LoadingSpinner from '../components/ui/LoadingSpinner';
import {
  UserGroupIcon,
  DocumentTextIcon,
  CreditCardIcon,
  BuildingStorefrontIcon,
  ChartBarIcon,
  BellIcon,
  ShieldCheckIcon,
  Cog6ToothIcon,
} from '@heroicons/react/24/outline';

export default function AdminDashboard() {
  const [selectedPeriod, setSelectedPeriod] = useState('today');
  const { hasRole } = useAuth();
  const navigate = useNavigate();

  // Only allow admin access
  if (!hasRole('admin')) {
    navigate('/');
    return null;
  }

  // Get basic stats without using admin API
  const { data: stats, isLoading } = useQuery({
    queryKey: ['admin-stats', selectedPeriod],
    queryFn: async () => {
      const [
        { count: usersCount },
        { count: vendorsCount },
        { count: tendersCount },
        { count: paymentsCount },
        { count: pendingVendorsCount },
        { count: activeVendorsCount },
        { count: publishedTendersCount },
        { count: completedPaymentsCount },
        { count: mseVendorsCount },
        { count: underReviewTendersCount },
        { data: totalPaymentAmount }
      ] = await Promise.all([
        supabase.from('profiles').select('*', { count: 'exact' }),
        supabase.from('vendors').select('*', { count: 'exact' }),
        supabase.from('tenders').select('*', { count: 'exact' }),
        supabase.from('payments').select('*', { count: 'exact' }),
        supabase.from('vendors').select('*', { count: 'exact' }).eq('status', 'Pending'),
        supabase.from('vendors').select('*', { count: 'exact' }).eq('status', 'Active'),
        supabase.from('tenders').select('*', { count: 'exact' }).eq('status', 'published'),
        supabase.from('payments').select('*', { count: 'exact' }).eq('status', 'completed'),
        supabase.from('vendors').select('*', { count: 'exact' }).eq('business_type', 'MSE'),
        supabase.from('tenders').select('*', { count: 'exact' }).eq('status', 'under_review'),
        supabase.from('payments').select('amount').eq('status', 'completed')
      ]);

      const totalAmount = totalPaymentAmount?.reduce((sum, payment) => sum + (payment.amount || 0), 0) || 0;

      return {
        users: usersCount,
        vendors: vendorsCount,
        tenders: tendersCount,
        payments: paymentsCount,
        pendingVendors: pendingVendorsCount,
        activeVendors: activeVendorsCount,
        publishedTenders: publishedTendersCount,
        completedPayments: completedPaymentsCount,
        mseVendors: mseVendorsCount,
        underReviewTenders: underReviewTendersCount,
        totalPaymentAmount: totalAmount
      };
    }
  });

  // Get recent activity logs
  const { data: recentActivity, isLoading: isLoadingActivity } = useQuery({
    queryKey: ['recent-activity'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('action_logs')
        .select(`
          *,
          profiles:user_id (
            first_name,
            last_name
          )
        `)
        .order('created_at', { ascending: false })
        .limit(5);

      if (error) throw error;
      return data;
    }
  });

  if (isLoading || isLoadingActivity) {
    return <LoadingSpinner />;
  }

  const quickActions = [
    {
      title: 'Manage Users',
      icon: UserGroupIcon,
      description: 'Add, edit, or manage user accounts',
      link: '/admin/users',
      color: 'bg-blue-500'
    },
    {
      title: 'View Tenders',
      icon: DocumentTextIcon,
      description: 'Monitor active tenders and bids',
      link: '/admin/tender-management',
      color: 'bg-green-500'
    },
    {
      title: 'Process Payments',
      icon: CreditCardIcon,
      description: 'Handle vendor payments',
      link: '/admin/payments',
      color: 'bg-yellow-500'
    },
    {
      title: 'Vendor Management',
      icon: BuildingStorefrontIcon,
      description: 'Manage vendor accounts and approvals',
      link: '/admin/vendors',
      color: 'bg-purple-500'
    },
    {
      title: 'View Reports',
      icon: ChartBarIcon,
      description: 'Access system reports and analytics',
      link: '/admin/reports',
      color: 'bg-indigo-500'
    },
    {
      title: 'Procurement Management',
      icon: DocumentTextIcon,
      description: 'Manage procurement accounts and settings',
      link: '/admin/procurement-management',
      color: 'bg-gray-500'
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
        <div className="flex items-center space-x-4">
          <select
            value={selectedPeriod}
            onChange={(e) => setSelectedPeriod(e.target.value)}
            className="input"
          >
            <option value="today">Today</option>
            <option value="week">This Week</option>
            <option value="month">This Month</option>
          </select>
          <button className="relative p-2 text-gray-400 hover:text-gray-500">
            <span className="sr-only">Notifications</span>
            <BellIcon className="h-6 w-6" />
            {stats?.pendingVendors > 0 && (
              <span className="absolute top-0 right-0 block h-2 w-2 rounded-full bg-red-400 ring-2 ring-white" />
            )}
          </button>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Users</p>
              <p className="text-2xl font-bold text-gray-900">{stats?.users || 0}</p>
            </div>
            <div className="p-3 bg-blue-100 rounded-full">
              <UserGroupIcon className="h-6 w-6 text-blue-600" />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Active Vendors</p>
              <p className="text-2xl font-bold text-gray-900">{stats?.activeVendors || 0}</p>
            </div>
            <div className="p-3 bg-green-100 rounded-full">
              <BuildingStorefrontIcon className="h-6 w-6 text-green-600" />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Published Tenders</p>
              <p className="text-2xl font-bold text-gray-900">{stats?.publishedTenders || 0}</p>
            </div>
            <div className="p-3 bg-yellow-100 rounded-full">
              <DocumentTextIcon className="h-6 w-6 text-yellow-600" />
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">Total Payments</p>
              <p className="text-2xl font-bold text-gray-900">₹{stats?.totalPaymentAmount?.toLocaleString() || 0}</p>
            </div>
            <div className="p-3 bg-purple-100 rounded-full">
              <CreditCardIcon className="h-6 w-6 text-purple-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {quickActions.map((action) => (
          <Link
            key={action.title}
            to={action.link}
            className="bg-white p-6 rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition-shadow"
          >
            <div className="flex items-center space-x-4">
              <div className={`p-3 ${action.color} bg-opacity-10 rounded-lg`}>
                <action.icon className={`h-6 w-6 ${action.color.replace('bg-', 'text-')}`} />
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900">{action.title}</h3>
                <p className="text-sm text-gray-500">{action.description}</p>
              </div>
            </div>
          </Link>
        ))}
      </div>

      {/* System Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Vendor Statistics</h2>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Total Vendors</span>
              <span className="font-semibold">{stats?.vendors || 0}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">MSE Vendors</span>
              <span className="font-semibold text-green-600">{stats?.mseVendors || 0}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Pending Approvals</span>
              <span className="font-semibold text-yellow-600">{stats?.pendingVendors || 0}</span>
            </div>
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Tender Overview</h2>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Total Tenders</span>
              <span className="font-semibold">{stats?.tenders || 0}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Under Review</span>
              <span className="font-semibold text-yellow-600">{stats?.underReviewTenders || 0}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Published</span>
              <span className="font-semibold text-green-600">{stats?.publishedTenders || 0}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Recent Activity */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="p-6">
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Recent Activity</h2>
          <div className="space-y-4">
            {recentActivity?.map((activity) => (
              <div key={activity.id} className="flex items-start space-x-3">
                <div className="flex-shrink-0">
                  <div className={`p-2 rounded-full ${
                    activity.action_type === 'status_change' 
                      ? 'bg-blue-100 text-blue-600' 
                      : activity.action_type === 'technical_score_update'
                      ? 'bg-yellow-100 text-yellow-600'
                      : 'bg-gray-100 text-gray-600'
                  }`}>
                    <ShieldCheckIcon className="h-5 w-5" />
                  </div>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-900">
                    {activity.profiles?.first_name} {activity.profiles?.last_name}
                  </p>
                  <p className="text-sm text-gray-500">
                    {activity.action_type === 'status_change'
                      ? `Changed ${activity.entity_type} status from ${activity.details?.previous_status} to ${activity.details?.new_status}`
                      : activity.action_type === 'technical_score_update'
                      ? `Updated technical score to ${activity.details?.new_score}%`
                      : 'Performed an action'}
                  </p>
                  <p className="text-xs text-gray-400">
                    {new Date(activity.created_at).toLocaleString()}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Alerts */}
      {stats?.pendingVendors > 0 && (
        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <div className="flex">
            <div className="flex-shrink-0">
              <BellIcon className="h-5 w-5 text-yellow-400" />
            </div>
            <div className="ml-3">
              <h3 className="text-sm font-medium text-yellow-800">
                Pending Approvals
              </h3>
              <div className="mt-2 text-sm text-yellow-700">
                <p>
                  You have {stats.pendingVendors} vendor{stats.pendingVendors > 1 ? 's' : ''} waiting for approval.
                </p>
              </div>
              <div className="mt-4">
                <div className="-mx-2 -my-1.5 flex">
                  <Link
                    to="/vendors"
                    className="bg-yellow-100 px-3 py-2 rounded-md text-sm font-medium text-yellow-800 hover:bg-yellow-200"
                  >
                    Review Vendors
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}