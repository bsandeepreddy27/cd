import { useState } from 'react';
import { Link } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '../lib/supabase';
import { toast } from 'react-hot-toast';
import LoadingSpinner from '../components/ui/LoadingSpinner';
import { useAuth } from '../hooks/useAuth';
import VendorApprovalList from '../components/vendors/VendorApprovalList';
import * as Yup from 'yup';


const vendorSchema = Yup.object().shape({
  name: Yup.string().required('Vendor name is required'),
  businessType: Yup.string().oneOf(['MSE', 'Large Enterprise']).required('Business type is required'),
  contactPerson: Yup.string().required('Contact person is required'),
  email: Yup.string().email('Invalid email').required('Email is required'),
  phone: Yup.string().required('Phone number is required'),
  address: Yup.string().required('Address is required'),
  mseCertificate: Yup.string().when('businessType', {
    is: 'MSE',
    then: (schema) => schema.required('MSE certificate number is required'),
    otherwise: (schema) => schema.optional(),
  }),
});

export default function UserManagement() {
  const [showForm, setShowForm] = useState(false);
  const [filterRole, setFilterStatus] = useState('all');
  const [showReasonModal, setShowReasonModal] = useState(false);
  const [rejectionReason, setRejectionReason] = useState('');
  const [selectedUserId, setSelectedUserId] = useState(null);
  const queryClient = useQueryClient();
  const { user } = useAuth();

  const { data: users, isLoading, error } = useQuery({
    queryKey: ['users'],
    queryFn: async () => {
      try {
        // Get all profiles with their roles and emails
        const { data: profiles, error: profilesError } = await supabase
          .from('profiles')
          .select(`
            id,
            email,
            first_name,
            last_name,
            role,
            department,
            employee_id,
            created_at
          `)
          .order('created_at', { ascending: false });

        if (profilesError) {
          console.error('Error fetching profiles:', profilesError);
          throw profilesError;
        }

        // For vendor profiles, get their vendor details
        const vendorProfiles = profiles.filter(p => p.role === 'vendor');
        if (vendorProfiles.length > 0) {
          const { data: vendorDetails, error: vendorError } = await supabase
            .from('vendors')
            .select('*')
            .in('user_id', vendorProfiles.map(p => p.id));

          if (vendorError) {
            console.error('Error fetching vendor details:', vendorError);
          } else {
            // Merge vendor details with profiles
            profiles.forEach(profile => {
              if (profile.role === 'vendor') {
                const vendorDetail = vendorDetails?.find(v => v.user_id === profile.id);
                if (vendorDetail) {
                  profile.vendor = vendorDetail;
                }
              }
            });
          }
        }

        return profiles || [];
      } catch (error) {
        console.error('Error in users query:', error);
        throw error;
      }
    },
    retry: 2,
    onError: (error) => {
      console.error('Query error:', error);
      toast.error('Failed to load users. Please try again.');
    }
  });

  const { data: pendingVendors, isLoading: isLoadingPending } = useQuery({
    queryKey: ['pending-vendors'],
    queryFn: async () => {
      try {
        const { data, error } = await supabase
          .from('vendors')
          .select('*')
          .eq('status', 'Pending')
          .order('created_at', { ascending: false });

        if (error) throw error;
        return data || [];
      } catch (error) {
        console.error('Error fetching pending vendors:', error);
        return [];
      }
    },
  });

  const updateUserStatus = useMutation({
    mutationFn: async ({ userId, status, reason = null }) => {
      const { data, error } = await supabase
        .from('profiles')
        .update({ 
          active: status === 'suspend' ? false : true,
          ...(status === 'suspend' && reason ? { suspension_reason: reason } : {})
        })
        .eq('id', userId)
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries(['users']);
      setShowReasonModal(false);
      setRejectionReason('');
      setSelectedUserId(null);
      toast.success('User status updated successfully');
    },
    onError: (error) => {
      console.error('Error updating user status:', error);
      toast.error(error.message || 'Failed to update user status');
      setShowReasonModal(false);
      setSelectedUserId(null);
    }
  });

  const handleSuspendUser = (userId) => {
    if (!userId) {
      toast.error('User ID is missing');
      return;
    }
    setSelectedUserId(userId);
    setShowReasonModal(true);
  };

  const confirmSuspension = () => {
    if (!selectedUserId) {
      toast.error('User ID is missing');
      return;
    }
    
    updateUserStatus.mutate({ 
      userId: selectedUserId, 
      status: 'suspend', 
      reason: rejectionReason 
    });
  };

  const filteredUsers = users ? users.filter(user => {
    if (filterRole === 'all') return true;
    return user.role === filterRole;
  }) : [];

  const adminCount = users?.filter(u => u.role === 'admin').length || 0;
  const procurementOfficerCount = users?.filter(u => u.role === 'procurement_officer').length || 0;
  const vendorCount = users?.filter(u => u.role === 'vendor').length || 0;

  if (isLoading) {
    return <LoadingSpinner />;
  }

  return (
    <div className="space-y-6">
      {showReasonModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg shadow-lg max-w-md w-full">
            <h3 className="text-xl font-semibold mb-4">Account Suspension Reason</h3>
            <p className="text-gray-600 mb-4">
              Please provide a reason for suspending this account. This will be recorded in the system.
            </p>
            <textarea
              className="input w-full h-32 mb-4"
              placeholder="Enter reason for suspension"
              value={rejectionReason}
              onChange={(e) => setRejectionReason(e.target.value)}
            ></textarea>
            <div className="flex justify-end space-x-2">
              <button 
                className="btn btn-secondary"
                onClick={() => {
                  setShowReasonModal(false);
                  setSelectedUserId(null);
                  setRejectionReason('');
                }}
              >
                Cancel
              </button>
              <button 
                className="btn btn-primary"
                onClick={confirmSuspension}
                disabled={!rejectionReason.trim() || updateUserStatus.isLoading}
              >
                {updateUserStatus.isLoading ? 'Processing...' : 'Confirm Suspension'}
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-900">User Management</h1>
      </div>

      {pendingVendors && pendingVendors.length > 0 && (
        <div className="card bg-yellow-50 border border-yellow-200">
          <h2 className="text-xl font-semibold text-yellow-900 mb-4">Pending Vendor Approvals</h2>
          <p className="text-yellow-800 mb-4">
            You have {pendingVendors.length} vendor{pendingVendors.length > 1 ? 's' : ''} waiting for approval.
          </p>
          <VendorApprovalList />
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div 
          className={`card cursor-pointer ${filterRole === 'all' ? 'ring-2 ring-primary-500' : ''}`}
          onClick={() => setFilterStatus('all')}
        >
          <h3 className="text-lg font-medium text-gray-900">All Users</h3>
          <p className="mt-2 text-3xl font-bold text-primary-600">{users?.length || 0}</p>
        </div>
        
        <div 
          className={`card cursor-pointer ${filterRole === 'admin' ? 'ring-2 ring-red-500' : ''}`}
          onClick={() => setFilterStatus('admin')}
        >
          <h3 className="text-lg font-medium text-gray-900">Administrators</h3>
          <p className="mt-2 text-3xl font-bold text-red-600">{adminCount}</p>
        </div>
        
        <div 
          className={`card cursor-pointer ${filterRole === 'procurement_officer' ? 'ring-2 ring-blue-500' : ''}`}
          onClick={() => setFilterStatus('procurement_officer')}
        >
          <h3 className="text-lg font-medium text-gray-900">Procurement Officers</h3>
          <p className="mt-2 text-3xl font-bold text-blue-600">{procurementOfficerCount}</p>
        </div>
        
        <div 
          className={`card cursor-pointer ${filterRole === 'vendor' ? 'ring-2 ring-green-500' : ''}`}
          onClick={() => setFilterStatus('vendor')}
        >
          <h3 className="text-lg font-medium text-gray-900">Vendors</h3>
          <p className="mt-2 text-3xl font-bold text-green-600">{vendorCount}</p>
        </div>
      </div>

      <div className="card">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold text-gray-900">
            {filterRole === 'all' ? 'User Directory' : 
             filterRole === 'Pending' ? 'Pending Approval' :
             filterRole === 'Active' ? 'Active Users' : 'Suspended Users'}
          </h2>
          
          <div className="flex space-x-2">
            <button 
              className={`btn ${filterRole === 'all' ? 'btn-primary' : 'btn-secondary'}`}
              onClick={() => setFilterStatus('all')}
            >
              All
            </button>
            <button 
              className={`btn ${filterRole === 'admin' ? 'btn-primary' : 'btn-secondary'}`}
              onClick={() => setFilterStatus('admin')}
            >
              Admins
            </button>
            <button 
              className={`btn ${filterRole === 'procurement_officer' ? 'btn-primary' : 'btn-secondary'}`}
              onClick={() => setFilterStatus('procurement_officer')}
            >
              Officers
            </button>
            <button 
              className={`btn ${filterRole === 'vendor' ? 'btn-primary' : 'btn-secondary'}`}
              onClick={() => setFilterStatus('vendor')}
            >
              Vendors
            </button>
          </div>
        </div>
        
        {isLoading ? (
          <LoadingSpinner />
        ) : filteredUsers.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Name
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Email
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Role
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Department
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Employee ID
                  </th>
                  {filterRole === 'vendor' && (
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Business Details
                    </th>
                  )}
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Actions
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredUsers.map((user) => {
                  const isAdmin = user.role === 'admin';
                  
                  return (
                    <tr key={user.id}>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {user.first_name} {user.last_name}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {user.email}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          isAdmin
                            ? 'bg-red-100 text-red-800'
                            : user.role === 'procurement_officer'
                            ? 'bg-blue-100 text-blue-800'
                            : 'bg-green-100 text-green-800'
                        }`}>
                          {user.role?.replace('_', ' ').toUpperCase()}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {user.department || '-'}
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        {user.employee_id || '-'}
                      </td>
                      {filterRole === 'vendor' && (
                        <td className="px-6 py-4 whitespace-nowrap">
                          {user.vendor ? (
                            <div>
                              <div>{user.vendor.name}</div>
                              <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                                user.vendor.business_type === 'MSE'
                                  ? 'bg-green-100 text-green-800'
                                  : 'bg-blue-100 text-blue-800'
                              }`}>
                                {user.vendor.business_type}
                              </span>
                              <span className={`ml-2 px-2 py-1 rounded-full text-xs font-medium ${
                                user.vendor.status === 'Active'
                                  ? 'bg-green-100 text-green-800'
                                  : user.vendor.status === 'Pending'
                                  ? 'bg-yellow-100 text-yellow-800'
                                  : 'bg-red-100 text-red-800'
                              }`}>
                                {user.vendor.status}
                              </span>
                            </div>
                          ) : (
                            <span className="text-gray-500">No vendor profile</span>
                          )}
                        </td>
                      )}
                      <td className="px-6 py-4 whitespace-nowrap text-sm">
                        <div className="flex space-x-2">
                          {!isAdmin && (
                            <button
                              onClick={() => handleSuspendUser(user.id)}
                              className="text-red-600 hover:text-red-900"
                              disabled={updateUserStatus.isLoading}
                            >
                              Suspend
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="text-center py-4 text-gray-500">
            {filterRole === 'all' 
              ? 'No users found.'
              : `No ${filterRole.replace('_', ' ')} users found.`}
          </div>
        )}
      </div>

      <div className="card bg-blue-50">
        <h2 className="text-xl font-semibold text-blue-900 mb-4">User Role Information</h2>
        <div className="prose max-w-none text-blue-800">
          <ul className="list-disc pl-5 space-y-2">
            <li>
              <strong>Administrators:</strong> Have full access to all system features and can manage other users
            </li>
            <li>
              <strong>Procurement Officers:</strong> Manage tenders, vendor approvals, and procurement processes
            </li>
            <li>
              <strong>Vendors:</strong> Can view and bid on tenders, manage their profiles, and track payments
            </li>
          </ul>
          <p className="mt-4">
            <strong>Note:</strong> User roles determine access levels and permissions throughout the system.
          </p>
        </div>
      </div>
    </div>
  );
}