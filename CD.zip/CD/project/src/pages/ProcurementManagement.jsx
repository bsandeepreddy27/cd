import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '../lib/supabase';
import { toast } from 'react-hot-toast';
import LoadingSpinner from '../components/ui/LoadingSpinner';
import { useAuth } from '../hooks/useAuth';

export default function ProcurementManagement() {
  const { hasRole } = useAuth();
  const navigate = useNavigate();

  // Only allow admin access
  if (!hasRole('admin')) {
    navigate('/');
    return null;
  }

  // Get procurement officers with their statistics
  const { data: procurementOfficers, isLoading } = useQuery({
    queryKey: ['procurement-officers'],
    queryFn: async () => {
      try {
        // Get officer stats from the view
        const { data: stats, error: statsError } = await supabase
          .from('procurement_officer_stats')
          .select('*')
          .order('last_tender_created', { ascending: false, nullsLast: true });

        if (statsError) {
          console.error('Error fetching officer stats:', statsError);
          throw statsError;
        }

        // Get recent activity for each officer
        const { data: recentActivity, error: activityError } = await supabase
          .from('recent_officer_activity')
          .select('*')
          .order('created_at', { ascending: false });

        if (activityError) {
          console.error('Error fetching recent activity:', activityError);
          throw activityError;
        }

        // Combine stats with recent activity
        return stats.map(officer => ({
          ...officer,
          recentActivity: recentActivity.filter(activity => 
            activity.officer_id === officer.officer_id
          )
        }));
      } catch (error) {
        console.error('Error in procurement officers query:', error);
        throw error;
      }
    },
    retry: 2,
    onError: (error) => {
      console.error('Query error:', error);
      toast.error('Failed to load procurement officers. Please try again.');
    }
  });

  if (isLoading) {
    return <LoadingSpinner />;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-900">Procurement Officers</h1>
        <Link to="/admin/tender-management" className="btn btn-primary">
          Manage Tenders
        </Link>
      </div>

      <div className="card">
        <h2 className="text-xl font-semibold text-gray-900 mb-4">Officer List</h2>
        {procurementOfficers && procurementOfficers.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Name
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Email
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Department
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Employee ID
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Total Tenders
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Active Tenders
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Vendors Approved
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Recent Activity
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Joined
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {procurementOfficers.map((officer) => (
                  <tr key={officer.officer_id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {officer.first_name} {officer.last_name}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {officer.email}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {officer.department || '-'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {officer.employee_id || '-'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex flex-col">
                        <span className="font-medium">{officer.total_tenders}</span>
                        <span className="text-xs text-gray-500">
                          {officer.awarded_tenders} awarded
                        </span>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                        {officer.active_tenders} active
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex flex-col">
                        <span className="font-medium">{officer.total_vendors_approved}</span>
                        {officer.recent_approvals > 0 && (
                          <span className="text-xs text-green-600">
                            +{officer.recent_approvals} this week
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {officer.recentActivity && officer.recentActivity.length > 0 ? (
                        <div className="text-sm">
                          <span className="font-medium text-green-600">
                            {officer.recentActivity.length} actions
                          </span>
                          <span className="text-gray-500"> in last 7 days</span>
                        </div>
                      ) : (
                        <span className="text-sm text-gray-500">No recent activity</span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {new Date(officer.joined_at).toLocaleDateString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="text-center py-4 text-gray-500">
            No procurement officers found.
          </div>
        )}
      </div>

      <div className="card bg-blue-50">
        <h2 className="text-xl font-semibold text-blue-900 mb-4">Officer Roles and Responsibilities</h2>
        <div className="prose max-w-none text-blue-800">
          <p>
            Procurement Officers are responsible for:
          </p>
          <ul className="list-disc pl-5 space-y-2">
            <li>Managing and overseeing the procurement process</li>
            <li>Reviewing and approving vendor applications</li>
            <li>Creating and publishing tenders</li>
            <li>Evaluating bids and awarding contracts</li>
            <li>Ensuring compliance with procurement policies</li>
            <li>Maintaining vendor relationships</li>
          </ul>
          <p className="mt-4">
            <strong>Note:</strong> All procurement officers have access to manage tenders, vendors, and payments within their assigned departments.
          </p>
        </div>
      </div>
    </div>
  );
}