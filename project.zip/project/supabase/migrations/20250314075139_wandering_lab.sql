/*
  # Update profiles role constraint

  1. Changes
    - Update the role CHECK constraint in profiles table 
    - Add index for role column for better performance
*/

-- Update the role CHECK constraint
ALTER TABLE profiles 
  DROP CONSTRAINT IF EXISTS profiles_role_check;

ALTER TABLE profiles 
  ADD CONSTRAINT profiles_role_check 
  CHECK (role IN ('vendor', 'procurement_officer', 'admin'));

-- Create index for role if it doesn't exist
CREATE INDEX IF NOT EXISTS idx_profiles_role_lookup ON profiles(role);