/*
  # Fix Profiles-Vendors Relationship

  1. Changes
    - Add proper foreign key constraint between vendors and profiles for user_id
    - Update the query in UserManagement.jsx to use the correct relationship
*/

-- Drop existing constraint if it exists
ALTER TABLE vendors
  DROP CONSTRAINT IF EXISTS vendors_user_id_fkey;

-- Add the correct foreign key constraint
ALTER TABLE vendors
  ADD CONSTRAINT vendors_user_id_fkey 
  FOREIGN KEY (user_id) 
  REFERENCES profiles(id);

-- Create index for the foreign key
CREATE INDEX IF NOT EXISTS idx_vendors_user_id_profiles ON vendors(user_id);