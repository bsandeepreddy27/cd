/*
  # Admin Registration System

  1. New Table
    - `admin_registration_codes` - Stores valid admin registration codes
    - Includes expiration and single-use tracking
  
  2. Security
    - Enable RLS
    - Only allow admins to manage codes
*/

-- Create admin_registration_codes table
CREATE TABLE IF NOT EXISTS admin_registration_codes (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  code TEXT NOT NULL UNIQUE,
  expires_at TIMESTAMPTZ NOT NULL,
  is_used BOOLEAN DEFAULT FALSE,
  created_by UUID REFERENCES auth.users(id),
  used_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  used_at TIMESTAMPTZ
);

-- Enable RLS
ALTER TABLE admin_registration_codes ENABLE ROW LEVEL SECURITY;

-- Only admins can manage codes
CREATE POLICY "Admins can manage registration codes"
  ON admin_registration_codes
  FOR ALL TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid()
      AND role = 'admin'
    )
  );

-- Function to validate admin registration code
CREATE OR REPLACE FUNCTION validate_admin_registration_code(registration_code TEXT)
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 
    FROM admin_registration_codes
    WHERE code = registration_code
    AND NOT is_used
    AND expires_at > NOW()
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to mark code as used
CREATE OR REPLACE FUNCTION use_admin_registration_code(registration_code TEXT, user_id UUID)
RETURNS BOOLEAN AS $$
BEGIN
  UPDATE admin_registration_codes
  SET 
    is_used = TRUE,
    used_by = user_id,
    used_at = NOW()
  WHERE code = registration_code
  AND NOT is_used
  AND expires_at > NOW();
  
  RETURN FOUND;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Insert initial admin registration code (expires in 30 days)
INSERT INTO admin_registration_codes (code, expires_at)
VALUES ('ADMIN2025', NOW() + INTERVAL '30 days')
ON CONFLICT DO NOTHING;