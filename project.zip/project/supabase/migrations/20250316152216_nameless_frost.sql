/*
  # Procurement Officer Statistics

  1. New Views
    - `procurement_officer_stats` - Aggregates statistics for procurement officers
    - `recent_officer_activity` - Tracks recent activity (7 days)
  
  2. Functions
    - Functions to calculate performance metrics
    - Functions to update statistics
  
  3. Triggers
    - Automatic statistics updates
    - Activity tracking
*/

-- Create view for procurement officer statistics
CREATE OR REPLACE VIEW procurement_officer_stats AS
WITH tender_stats AS (
  SELECT 
    created_by as officer_id,
    COUNT(*) as total_tenders,
    COUNT(*) FILTER (WHERE status = 'published') as active_tenders,
    COUNT(*) FILTER (WHERE status = 'awarded') as awarded_tenders,
    MAX(created_at) as last_tender_created
  FROM tenders
  GROUP BY created_by
),
vendor_stats AS (
  SELECT 
    approved_by as officer_id,
    COUNT(*) as total_vendors_approved,
    COUNT(*) FILTER (WHERE approved_at >= NOW() - INTERVAL '7 days') as recent_approvals,
    MAX(approved_at) as last_vendor_approved
  FROM vendors
  WHERE status = 'Active'
  GROUP BY approved_by
)
SELECT 
  p.id as officer_id,
  p.first_name,
  p.last_name,
  p.email,
  p.department,
  p.employee_id,
  p.created_at as joined_at,
  COALESCE(ts.total_tenders, 0) as total_tenders,
  COALESCE(ts.active_tenders, 0) as active_tenders,
  COALESCE(ts.awarded_tenders, 0) as awarded_tenders,
  COALESCE(vs.total_vendors_approved, 0) as total_vendors_approved,
  COALESCE(vs.recent_approvals, 0) as recent_approvals,
  ts.last_tender_created,
  vs.last_vendor_approved
FROM profiles p
LEFT JOIN tender_stats ts ON p.id = ts.officer_id
LEFT JOIN vendor_stats vs ON p.id = vs.officer_id
WHERE p.role = 'procurement_officer';

-- Create view for recent officer activity
CREATE OR REPLACE VIEW recent_officer_activity AS
SELECT 
  p.id as officer_id,
  p.first_name,
  p.last_name,
  al.action_type,
  al.entity_type,
  al.details,
  al.created_at
FROM profiles p
JOIN action_logs al ON p.id = al.user_id
WHERE 
  p.role = 'procurement_officer'
  AND al.created_at >= NOW() - INTERVAL '7 days'
ORDER BY al.created_at DESC;

-- Function to calculate officer performance score
CREATE OR REPLACE FUNCTION calculate_officer_performance(officer_id UUID)
RETURNS INTEGER AS $$
DECLARE
  performance_score INTEGER;
  tender_count INTEGER;
  vendor_count INTEGER;
  recent_activity INTEGER;
BEGIN
  -- Get tender metrics
  SELECT COUNT(*) INTO tender_count
  FROM tenders
  WHERE created_by = officer_id
  AND created_at >= NOW() - INTERVAL '30 days';

  -- Get vendor metrics
  SELECT COUNT(*) INTO vendor_count
  FROM vendors
  WHERE approved_by = officer_id
  AND approved_at >= NOW() - INTERVAL '30 days';

  -- Get recent activity count
  SELECT COUNT(*) INTO recent_activity
  FROM action_logs
  WHERE user_id = officer_id
  AND created_at >= NOW() - INTERVAL '7 days';

  -- Calculate weighted score (example formula)
  performance_score := (tender_count * 10) + (vendor_count * 15) + (recent_activity * 5);

  -- Ensure score is between 0 and 100
  RETURN LEAST(100, GREATEST(0, performance_score));
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to get officer activity summary
CREATE OR REPLACE FUNCTION get_officer_activity_summary(officer_id UUID)
RETURNS TABLE (
  activity_date DATE,
  tenders_created INTEGER,
  vendors_approved INTEGER,
  total_actions INTEGER
) AS $$
BEGIN
  RETURN QUERY
  WITH daily_activity AS (
    SELECT 
      DATE(created_at) as date,
      COUNT(*) FILTER (WHERE entity_type = 'tender') as tender_count,
      COUNT(*) FILTER (WHERE entity_type = 'vendor') as vendor_count,
      COUNT(*) as total_count
    FROM action_logs
    WHERE 
      user_id = officer_id
      AND created_at >= NOW() - INTERVAL '30 days'
    GROUP BY DATE(created_at)
  )
  SELECT 
    date as activity_date,
    tender_count as tenders_created,
    vendor_count as vendors_approved,
    total_count as total_actions
  FROM daily_activity
  ORDER BY date DESC;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_action_logs_user_id_created_at 
  ON action_logs(user_id, created_at);

CREATE INDEX IF NOT EXISTS idx_tenders_created_by_status 
  ON tenders(created_by, status);

CREATE INDEX IF NOT EXISTS idx_vendors_approved_by_status 
  ON vendors(approved_by, status);

-- Grant necessary permissions
GRANT SELECT ON procurement_officer_stats TO authenticated;
GRANT SELECT ON recent_officer_activity TO authenticated;