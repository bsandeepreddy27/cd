/*
  # Fix action_logs relationship with profiles

  1. Changes
    - Add user_id foreign key constraint to action_logs table
    - Update existing queries to use the correct relationship
*/

-- Add foreign key constraint to action_logs table
ALTER TABLE action_logs
  DROP CONSTRAINT IF EXISTS action_logs_user_id_fkey,
  ADD CONSTRAINT action_logs_user_id_fkey 
  FOREIGN KEY (user_id) 
  REFERENCES profiles(id);

-- Create index for the foreign key
CREATE INDEX IF NOT EXISTS idx_action_logs_user_id_profiles ON action_logs(user_id);