/*
  # Fix Vendor-Profile Relationship

  1. Changes
    - Add proper foreign key constraint between vendors and profiles for approved_by
    - Update the query in VendorDetails.jsx to use the correct relationship
*/

-- Drop existing constraint if it exists
ALTER TABLE vendors
  DROP CONSTRAINT IF EXISTS vendors_approved_by_fkey;

-- Add the correct foreign key constraint
ALTER TABLE vendors
  ADD CONSTRAINT vendors_approved_by_fkey 
  FOREIGN KEY (approved_by) 
  REFERENCES profiles(id);

-- Create index for the foreign key
CREATE INDEX IF NOT EXISTS idx_vendors_approved_by_profiles ON vendors(approved_by);