import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import { toast } from 'react-hot-toast';
import LoadingSpinner from '../../components/ui/LoadingSpinner';

export default function SignOut() {
  const navigate = useNavigate();
  const { signOut } = useAuth();

  useEffect(() => {
    const performSignOut = async () => {
      try {
        await signOut();
        toast.success('You have been signed out successfully');
        navigate('/login');
      } catch (error) {
        console.error('Error signing out:', error);
        toast.error('Failed to sign out. Please try again.');
        navigate('/');
      }
    };

    performSignOut();
  }, [signOut, navigate]);

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <h2 className="mt-6 text-center text-3xl font-extrabold text-gray-900">
          Signing Out
        </h2>
        <div className="mt-8">
          <LoadingSpinner />
        </div>
      </div>
    </div>
  );
}