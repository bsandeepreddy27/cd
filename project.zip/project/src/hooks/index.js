// Export all hooks from a single file
export { useAuth, AuthProvider } from './useAuth';