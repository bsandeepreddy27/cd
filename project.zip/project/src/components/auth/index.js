// Export all auth components from a single file
export { default as ProtectedRoute } from './ProtectedRoute';
export { default as RoleBasedRoute } from './RoleBasedRoute';